<?php
namespace app\components;

/**
 * Dummy User class to simulate authentication.
 * Provides permission methods used in the assignment.
 */
class DummyUser
{
    public function canView()
    {
        return true; // allow viewing
    }

    public function canCreate()
    {
        return true; // allow creating
    }

    public function canUpdate()
    {
        return true; // allow updating
    }

    public function canDelete()
    {
        return false; // deny deleting for demo
    }
}
