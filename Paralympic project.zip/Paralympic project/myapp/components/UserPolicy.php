<?php
namespace app\components;

/**
 * Minimal role-based policy used by the app via the global $USER.
 * In a real system you’d read the role from session/DB/SSO, but the task
 * only needs the methods (canView/canCreate/canUpdate/canDelete).
 */
class UserPolicy
{
    private string $role;

    public function __construct(string $role = 'viewer')
    {
        $this->role = $role; // 'viewer' | 'editor' | 'admin'
    }

    // Action-level checks. We accept a $resource and optional $model for row checks.
    public function canView(string $resource, $model = null): bool
    {
        return in_array($this->role, ['viewer','editor','admin'], true);
    }

    public function canCreate(string $resource, $model = null): bool
    {
        return in_array($this->role, ['editor','admin'], true);
    }

    public function canUpdate(string $resource, $model = null): bool
    {
        return in_array($this->role, ['editor','admin'], true);
    }

    public function canDelete(string $resource, $model = null): bool
    {
        return $this->role === 'admin';
    }
}
