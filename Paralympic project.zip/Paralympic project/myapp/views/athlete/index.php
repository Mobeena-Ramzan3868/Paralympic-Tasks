<?php
/**
 * @var yii\web\View         $this
 * @var app\models\Athlete[] $athletes
 * @var string               $q
 * @var string               $sport
 * @var string               $sort
 * @var string               $order
 * @var int                  $page
 * @var int                  $perPage
 * @var int                  $total
 * @var int                  $totalPages
 * @var int                  $rowStart  // <-- used for the row number column
 */

use yii\helpers\Html;
use yii\helpers\Url;

$this->title = 'Athletes';

/**
 * Keep current query string when building links (sort, pagination, etc.)
 * $clean($changes) merges overrides into the current query.
 */
$qs = Yii::$app->request->get();
if (!is_array($qs)) {
    $qs = [];
}
$clean = static fn(array $changes): string => Url::to(array_merge(['athlete/index'], $qs, $changes));

/**
 * Draw a tiny arrow beside the active sort column.
 * Also expose 'aria-sort' later for assistive tech.
 */
$arrow = static fn(string $col, string $currSort, string $currOrder): string =>
    ($currSort === $col ? ($currOrder === 'asc' ? ' ▲' : ' ▼') : '');

/** Global permission object (project-specific) */
global $USER;
?>
<div class="page">
    <header class="page-header">
        <h1><?= Html::encode($this->title) ?></h1>

        <?php if (isset($USER) && method_exists($USER, 'canCreate') && $USER->canCreate('athlete')): ?>
            <?= Html::a('Register New Athlete', ['create'], ['class' => 'btn btn-accent']) ?>
        <?php endif; ?>
    </header>

    <?php if (Yii::$app->session->hasFlash('success')): ?>
        <div class="alert success"><?= Html::encode(Yii::$app->session->getFlash('success')) ?></div>
    <?php endif; ?>

    <?php if (Yii::$app->session->hasFlash('error')): ?>
        <div class="alert danger"><?= Html::encode(Yii::$app->session->getFlash('error')) ?></div>
    <?php endif; ?>

    <!-- Filters: simple text search + sport + per-page; Reset clears all -->
    <section class="card filters">
        <form method="get" action="<?= Html::encode(Url::to(['athlete/index'])) ?>" class="filter-grid" novalidate>
            <div class="field">
                <label for="q">Search name</label>
                <input id="q" type="text" name="q" value="<?= Html::encode($q) ?>" placeholder="Given or family name"
                    autocomplete="off">
            </div>

            <div class="field">
                <label for="sport">Sport</label>
                <select id="sport" name="sport">
                    <option value="">(any)</option>
                    <?php foreach (\app\models\Athlete::SPORTS as $s): ?>
                        <option value="<?= Html::encode($s) ?>" <?= $sport === $s ? 'selected' : '' ?>>
                            <?= Html::encode(ucfirst($s)) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field small">
                <label for="perPage">Per page</label>
                <select id="perPage" name="perPage">
                    <?php foreach ([10, 20, 30, 50] as $opt): ?>
                        <option value="<?= $opt ?>" <?= ((int) $perPage === $opt) ? 'selected' : '' ?>><?= $opt ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="actions">
                <button type="submit" class="btn">Apply</button>
                <a class="btn ghost" href="<?= Html::encode(Url::to(['athlete/index'])) ?>">Reset</a>
            </div>
        </form>

        <div class="list-meta">
            <strong>Total:</strong> <?= (int) $total ?> record(s)
            <?php if ($total > 0): ?> • Page <?= (int) $page ?> of <?= (int) $totalPages ?><?php endif; ?>
        </div>
    </section>

    <!-- Table: sticky header, row numbers, sortable columns, inline actions -->
    <section class="card table-card">
        <div class="table-wrap">
            <table class="grid">
                <caption class="sr-only">
                    Athletes list (<?= (int) $total ?> total<?= $total ? ", page $page of $totalPages" : '' ?>)
                </caption>
                <thead>
                    <tr>
                        <th class="num-col">#</th>
                        <?php
                        $cols = [
                            'givenName' => 'Given Name',
                            'familyName' => 'Family Name',
                            'dateOfBirth' => 'DOB',
                            'sport' => 'Sport',
                            'personalBestTime' => 'PB (hh:mm:ss)',
                            'created_at' => 'Registered',
                        ];

                        foreach ($cols as $key => $label):
                            // toggle next direction for this column
                            $nextDir = ($sort === $key && $order === 'asc') ? 'desc' : 'asc';
                            $url = $clean(['sort' => $key, 'order' => $nextDir, 'page' => 1]);
                            $isActive = $sort === $key;
                            $ariaSort = $isActive ? ($order === 'asc' ? 'ascending' : 'descending') : 'none';
                            ?>
                            <th aria-sort="<?= Html::encode($ariaSort) ?>">
                                <a href="<?= Html::encode($url) ?>">
                                    <?= Html::encode($label) . $arrow($key, $sort, $order) ?>
                                </a>
                            </th>
                        <?php endforeach; ?>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (!$athletes): ?>
                        <tr>
                            <td colspan="8">
                                <div class="empty">
                                    <p>No athletes found.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else:
                        /** Row counter continues across pages using $rowStart (from controller) */
                        $i = (int) $rowStart;
                        foreach ($athletes as $a): ?>
                            <tr>
                                <td class="num-col mono muted"><?= $i++ ?></td>
                                <td><strong><?= Html::encode($a->givenName) ?></strong></td>
                                <td><?= Html::encode($a->familyName) ?></td>
                                <td class="mono"><?= Html::encode($a->dateOfBirth) ?></td>
                                <td><span class="chip"><?= Html::encode($a->sport) ?></span></td>
                                <td class="mono"><?= Html::encode($a->personalBestTime) ?></td>
                                <td class="mono muted"><?= Html::encode($a->created_at) ?></td>
                                <td class="row-actions">
                                    <?php if (isset($USER) && method_exists($USER, 'canUpdate') && $USER->canUpdate('athlete', $a)): ?>
                                        <?= Html::a('Edit', ['update', 'id' => $a->id], ['class' => 'btn tiny']) ?>
                                    <?php endif; ?>

                                    <?php if (isset($USER) && method_exists($USER, 'canDelete') && $USER->canDelete('athlete', $a)): ?>
                                        <!-- POST + CSRF form; controller's VerbFilter enforces POST-only delete -->
                                        <form action="<?= Html::encode(Url::to(['athlete/delete', 'id' => $a->id])) ?>"
                                            method="post" class="inline">
                                            <input type="hidden" name="<?= Html::encode(Yii::$app->request->csrfParam) ?>"
                                                value="<?= Html::encode(Yii::$app->request->getCsrfToken()) ?>">
                                            <button type="submit" class="btn tiny danger">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach;
                    endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
            <!-- Simple pagination; keeps current filters/sort -->
            <div class="pagination">
                <?php
                if ($page > 1) {
                    echo Html::a('‹ Prev', $clean(['page' => $page - 1]), ['class' => 'btn tiny ghost', 'rel' => 'prev']);
                }

                $start = max(1, $page - 3);
                $end = min($totalPages, $page + 3);

                if ($start > 1) {
                    echo Html::a('1', $clean(['page' => 1]), ['class' => 'btn tiny ghost']);
                    echo '<span class="dots">…</span>';
                }

                for ($p = $start; $p <= $end; $p++) {
                    if ($p === (int) $page) {
                        echo '<span class="btn tiny current" aria-current="page">' . Html::encode((string) $p) . '</span>';
                    } else {
                        echo Html::a((string) $p, $clean(['page' => $p]), ['class' => 'btn tiny ghost']);
                    }
                }

                if ($end < $totalPages) {
                    echo '<span class="dots">…</span>';
                    echo Html::a((string) $totalPages, $clean(['page' => $totalPages]), ['class' => 'btn tiny ghost']);
                }

                if ($page < $totalPages) {
                    echo Html::a('Next ›', $clean(['page' => $page + 1]), ['class' => 'btn tiny ghost', 'rel' => 'next']);
                }
                ?>
            </div>
        <?php endif; ?>
    </section>
</div>

<style>
    :root {
        --bg: #f6f8fb;
        --panel: #ffffff;
        --text: #0b1f34;
        --muted: #5b6b7a;
        --border: #e6edf3;
        --primary: #0b5fff;
        --accent: #008e4c;
        --danger: #c71f2d;
        --link: #0b5fff;
        --shadow: 0 6px 18px rgba(2, 20, 44, .06);
    }

    .page {
        color: var(--text);
    }

    .page-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin: 22px 0 14px;
    }

    .page-header h1 {
        font-size: 48px;
        font-weight: 800;
        letter-spacing: .4px;
        margin: 0;
    }

    .card {
        background: var(--panel);
        border: 1px solid var(--border);
        border-radius: 16px;
        box-shadow: var(--shadow);
        padding: 16px;
        margin-bottom: 16px;
    }

    .filters .filter-grid {
        display: grid;
        grid-template-columns: 1fr 260px 120px auto;
        gap: 16px;
        align-items: end;
    }

    .filters .field label {
        display: block;
        font-weight: 600;
        margin-bottom: 6px;
        color: var(--muted);
    }

    .filters input,
    .filters select {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid var(--border);
        border-radius: 10px;
        background: #fff;
    }

    .filters .actions {
        display: flex;
        gap: 8px;
        align-items: center;
    }

    .list-meta {
        margin-top: 10px;
        color: var(--muted);
    }

    .table-card {
        padding: 0;
    }

    .table-wrap {
        overflow: auto;
        border-radius: 16px;
    }

    .grid {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        min-width: 900px;
    }

    .grid thead th {
        position: sticky;
        top: 0;
        z-index: 2;
        background: #f1f5fb;
        color: #20344d;
        font-weight: 700;
        letter-spacing: .2px;
    }

    .grid th,
    .grid td {
        padding: 14px 16px;
        border-bottom: 1px solid var(--border);
    }

    .grid tbody tr:hover {
        background: #fbfdff;
    }

    .grid a {
        color: var(--link);
        text-decoration: none;
    }

    .grid a:hover {
        text-decoration: underline;
    }

    .num-col {
        width: 64px;
        text-align: right;
    }

    .muted {
        color: var(--muted);
    }

    .mono {
        font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace;
    }

    .row-actions {
        white-space: nowrap;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .inline {
        display: inline;
        margin: 0;
    }

    .btn {
        display: inline-block;
        padding: 10px 14px;
        border-radius: 12px;
        border: 1px solid var(--border);
        background: #fff;
        color: var(--text);
        text-decoration: none;
        font-weight: 600;
        line-height: 1;
        box-shadow: var(--shadow);
    }

    .btn:hover {
        filter: brightness(.98);
    }

    .btn:focus {
        outline: 3px solid rgba(11, 95, 255, .25);
        outline-offset: 2px;
    }

    .btn.ghost {
        background: transparent;
        border-color: var(--border);
    }

    .btn.tiny {
        padding: 6px 10px;
        border-radius: 10px;
        box-shadow: none;
    }

    .btn.danger {
        border-color: #ffd6da;
        background: #fff4f5;
        color: var(--danger);
    }

    .btn.btn-accent {
        border-color: #bfead4;
        background: linear-gradient(180deg, #00a85a, #008e4c);
        color: #fff;
    }

    .btn.btn-accent:hover {
        filter: brightness(.98);
    }

    .chip {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 999px;
        background: #eef7ff;
        border: 1px solid #d7e7ff;
        font-weight: 600;
    }

    .empty {
        padding: 18px;
        text-align: center;
        color: var(--muted);
    }

    .alert {
        padding: 12px 14px;
        border-radius: 12px;
        margin: 10px 0 14px;
        border: 1px solid;
    }

    .alert.success {
        background: #edfbef;
        border-color: #bfead4;
        color: #155b2a;
    }

    .alert.danger {
        background: #fff4f5;
        border-color: #ffd6da;
        color: #7f1d1d;
    }

    .pagination {
        display: flex;
        gap: 8px;
        align-items: center;
        padding: 14px;
    }

    .pagination .btn.current {
        background: #eef4ff;
        border-color: #cfe0ff;
        color: #1f3e82;
    }

    .pagination .dots {
        color: var(--muted);
        padding: 0 6px;
    }

    /* Screen-reader only (for <caption>) */
    .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border: 0;
    }

    @media (max-width: 980px) {
        .filters .filter-grid {
            grid-template-columns: 1fr 1fr;
        }

        .filters .actions {
            justify-content: flex-start;
        }
    }
</style>