<?php
/** @var $this yii\web\View */
/** @var $model app\models\Athlete */

use yii\helpers\Html;

$this->title = $model->isNewRecord ? 'Register Athlete' : 'Update Athlete';

/**
 * Error accessors:
 * - Prefer model->errorsFor($attr) if you added it (from my last message),
 *   otherwise fall back to the manual bag $model->getManualErrors().
 */
$bag = method_exists($model, 'getManualErrors') ? (array) $model->getManualErrors() : [];
$errorsFor = function (string $attr) use ($model, $bag): array {
    if (method_exists($model, 'errorsFor')) {
        return (array) $model->errorsFor($attr);
    }
    return $bag[$attr] ?? [];
};

/**
 * Sticky value helper:
 * - Keep the user's POSTed input when validation fails
 * - Otherwise show the model's current value
 * - Always escape for safe output
 */
$val = function (string $name) use ($model) {
    $posted = Yii::$app->request->post($name, null);
    $raw = $posted !== null ? (string) $posted : (string) $model->$name;
    return Html::encode($raw);
};

/** 
 * Date input wants YYYY-MM-DD. If it's not valid, keep it empty so
 * the native date picker doesn't get confused.
 */
$dobRaw = Yii::$app->request->post('dateOfBirth', $model->dateOfBirth);
$dobForDateInput = (is_string($dobRaw) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dobRaw)) ? $dobRaw : '';

/** Selected sport: prefer posted value to keep selection on error */
$postedSport = Yii::$app->request->post('sport', $model->sport);

/** Sport options: use helper if present, else the constant */
$sports = method_exists($model, 'sportsOptions')
    ? $model::sportsOptions()
    : array_combine($model::SPORTS, $model::SPORTS);
?>
<div class="page">
    <header class="page-header">
        <h1><?= Html::encode($this->title) ?></h1>
        <?= Html::a('Back to list', ['index'], ['class' => 'btn ghost']) ?>
    </header>

    <?php if (Yii::$app->session->hasFlash('success')): ?>
        <div class="alert success"><?= Html::encode(Yii::$app->session->getFlash('success')) ?></div>
    <?php endif; ?>

    <?php if (Yii::$app->session->hasFlash('error') && empty($bag)): ?>
        <!-- Show a general error only if we don't already show field errors -->
        <div class="alert danger"><?= Html::encode(Yii::$app->session->getFlash('error')) ?></div>
    <?php endif; ?>

    <?php
    // Optional error summary (counts all field errors)
    $allAttrs = ['givenName', 'familyName', 'dateOfBirth', 'sport', 'personalBestTime'];
    $errorCount = 0;
    foreach ($allAttrs as $a) {
        $errorCount += count($errorsFor($a));
    }
    if ($errorCount > 0): ?>
        <!-- <div class="alert danger error-summary">
            <?= Html::encode("Please fix the $errorCount highlighted field" . ($errorCount > 1 ? 's' : '') . ".") ?>
        </div> -->
    <?php endif; ?>

    <section class="card">
        <!-- We keep novalidate to rely on server-side (assignment spec).
             If you want browser hints, remove novalidate. -->
        <form method="post" action="" class="form-grid" novalidate>
            <input type="hidden" name="<?= Html::encode(Yii::$app->request->csrfParam) ?>"
                value="<?= Html::encode(Yii::$app->request->getCsrfToken()) ?>">

            <!-- Given Name -->
            <?php $gErr = $errorsFor('givenName'); ?>
            <div class="field <?= $gErr ? 'has-error' : '' ?>">
                <label for="givenName">Given Name</label>
                <input id="givenName" type="text" name="givenName" value="<?= $val('givenName') ?>" minlength="3"
                    autocomplete="given-name" aria-invalid="<?= $gErr ? 'true' : 'false' ?>">
                <?php if ($gErr): ?>
                    <div class="help" id="givenName-help"><?= Html::encode(implode(' ', $gErr)) ?></div>
                <?php endif; ?>
            </div>

            <!-- Family Name -->
            <?php $fErr = $errorsFor('familyName'); ?>
            <div class="field <?= $fErr ? 'has-error' : '' ?>">
                <label for="familyName">Family Name</label>
                <input id="familyName" type="text" name="familyName" value="<?= $val('familyName') ?>" minlength="3"
                    autocomplete="family-name" aria-invalid="<?= $fErr ? 'true' : 'false' ?>">
                <?php if ($fErr): ?>
                    <div class="help" id="familyName-help"><?= Html::encode(implode(' ', $fErr)) ?></div>
                <?php endif; ?>
            </div>

            <!-- Date of Birth -->
            <?php $dErr = $errorsFor('dateOfBirth'); ?>
            <div class="field <?= $dErr ? 'has-error' : '' ?>">
                <label for="dateOfBirth">Date of Birth</label>
                <input id="dateOfBirth" type="date" name="dateOfBirth" value="<?= Html::encode($dobForDateInput) ?>"
                    aria-invalid="<?= $dErr ? 'true' : 'false' ?>">
                <?php if ($dErr): ?>
                    <div class="help" id="dateOfBirth-help"><?= Html::encode(implode(' ', $dErr)) ?></div>
                <?php endif; ?>
            </div>

            <!-- Sport -->
            <?php $sErr = $errorsFor('sport'); ?>
            <div class="field <?= $sErr ? 'has-error' : '' ?>">
                <label for="sport">Sport</label>
                <select id="sport" name="sport" aria-invalid="<?= $sErr ? 'true' : 'false' ?>">
                    <option value="">-- select --</option>
                    <?php foreach ($sports as $value => $label): ?>
                        <option value="<?= Html::encode($value) ?>" <?= ($postedSport === $value ? 'selected' : '') ?>>
                            <?= Html::encode(ucfirst($label)) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if ($sErr): ?>
                    <div class="help" id="sport-help"><?= Html::encode(implode(' ', $sErr)) ?></div>
                <?php endif; ?>
            </div>

            <!-- Personal Best Time -->
            <?php $tErr = $errorsFor('personalBestTime'); ?>
            <div class="field <?= $tErr ? 'has-error' : '' ?>">
                <label for="personalBestTime">Personal Best Time (hh:mm:ss)</label>
                <input id="personalBestTime" type="text" name="personalBestTime" placeholder="hh:mm:ss"
                    value="<?= $val('personalBestTime') ?>" inputmode="numeric" pattern="^\d{2}:[0-5]\d:[0-5]\d$"
                    title="Use hh:mm:ss (e.g., 00:59:30)" aria-invalid="<?= $tErr ? 'true' : 'false' ?>">
                <small class="hint">Example: 00:59:30</small>
                <?php if ($tErr): ?>
                    <div class="help" id="personalBestTime-help"><?= Html::encode(implode(' ', $tErr)) ?></div>
                <?php endif; ?>
            </div>

            <!-- Actions -->
            <div class="form-actions">
                <button type="submit" class="btn btn-accent">Save</button>
                <?= Html::a('Cancel', ['index'], ['class' => 'btn ghost']) ?>
            </div>
        </form>
    </section>
</div>

<style>
    :root {
        --bg: #f6f8fb;
        --panel: #ffffff;
        --text: #0b1f34;
        --muted: #5b6b7a;
        --border: #e6edf3;
        --primary: #0b5fff;
        --accent: #008e4c;
        --danger: #c71f2d;
        --shadow: 0 6px 18px rgba(2, 20, 44, .06);
    }

    .page {
        color: var(--text);
    }

    .page-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin: 22px 0 14px;
    }

    .page-header h1 {
        font-size: 40px;
        font-weight: 800;
        letter-spacing: .3px;
        margin: 0;
    }

    .card {
        background: var(--panel);
        border: 1px solid var(--border);
        border-radius: 16px;
        box-shadow: var(--shadow);
        padding: 22px;
    }

    .form-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(260px, 1fr));
        gap: 18px 20px;
    }

    .field label {
        display: block;
        font-weight: 700;
        margin: 2px 0 8px;
        color: #233a54;
    }

    .field input,
    .field select {
        width: 100%;
        padding: 12px 14px;
        border: 1px solid var(--border);
        background: #fff;
        border-radius: 12px;
    }

    .field input:focus,
    .field select:focus {
        outline: 3px solid rgba(11, 95, 255, .18);
        outline-offset: 1px;
    }

    .hint {
        color: var(--muted);
        display: block;
        margin-top: 6px;
    }

    .help {
        color: #a4000f;
        margin-top: 8px;
        font-size: .95em;
    }

    .field.has-error input,
    .field.has-error select {
        border-color: #ffb3ba;
        background: #fff7f7;
    }

    .error-summary {
        /* make summary visually distinct from per-field errors */
        border-style: dashed;
    }

    .form-actions {
        grid-column: 1 / -1;
        display: flex;
        gap: 10px;
        margin-top: 8px;
    }

    .btn {
        display: inline-block;
        padding: 11px 16px;
        border-radius: 12px;
        border: 1px solid var(--border);
        background: #fff;
        color: #fff0;
        color: var(--text);
        font-weight: 700;
        text-decoration: none;
        box-shadow: var(--shadow);
    }

    .btn:hover {
        filter: brightness(.98);
    }

    .btn:focus {
        outline: 3px solid rgba(11, 95, 255, .25);
        outline-offset: 2px;
    }

    .btn.ghost {
        background: transparent;
    }

    .btn.btn-accent {
        border-color: #bfead4;
        background: linear-gradient(180deg, #00a85a, #008e4c);
        color: #fff;
    }

    .alert {
        padding: 12px 14px;
        border-radius: 12px;
        margin: 10px 0 14px;
        border: 1px solid;
    }

    .alert.success {
        background: #edfbef;
        border-color: #bfead4;
        color: #155b2a;
    }

    .alert.danger {
        background: #fff4f5;
        border-color: #ffd6da;
        color: #7f1d1d;
    }

    @media (max-width: 880px) {
        .form-grid {
            grid-template-columns: 1fr;
        }
    }
</style>