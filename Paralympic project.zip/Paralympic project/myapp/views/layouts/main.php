<?php
/**
 * Main layout
 *
 * - Registers assets + common meta tags (charset, viewport, SEO).
 * - Renders a responsive app bar with brand + nav.
 * - Adds an accessible "skip to content" link and ARIA hints.
 * - Sticky footer with light IPC styling.
 *
 * @var yii\web\View $this
 * @var string       $content
 */

use app\assets\AppAsset;
use app\widgets\Alert;
use yii\bootstrap5\Breadcrumbs;
use yii\helpers\Html;
use yii\helpers\Url;

// Register compiled CSS/JS
AppAsset::register($this);

// Meta tags (SEO + PWA niceties)
$this->registerCsrfMetaTags();
$this->registerMetaTag(['charset' => Yii::$app->charset], 'charset');
$this->registerMetaTag(['name' => 'viewport', 'content' => 'width=device-width, initial-scale=1, shrink-to-fit=no']);
$this->registerMetaTag(['name' => 'description', 'content' => $this->params['meta_description'] ?? '']);
$this->registerMetaTag(['name' => 'keywords', 'content' => $this->params['meta_keywords'] ?? '']);
$this->registerMetaTag(['name' => 'theme-color', 'content' => '#1b2733']); // browser UI color on mobile
if (!empty($this->params['canonical'])) {
    $this->registerLinkTag(['rel' => 'canonical', 'href' => Url::to($this->params['canonical'], true)]);
}
$this->registerLinkTag(['rel' => 'icon', 'type' => 'image/x-icon', 'href' => Yii::getAlias('@web/favicon.ico')]);

// Tiny helper to mark active nav items
$currentRoute = $this->context->route ?? Yii::$app->requestedRoute ?? '';
$isActive = static function (string $routeLike) use ($currentRoute): bool {
    $routeLike = ltrim($routeLike, '/');
    return $routeLike !== '' && str_starts_with($currentRoute, $routeLike);
};

// Auth helpers (optional: show Login/Logout)
$user = Yii::$app->user ?? null;
$isGuest = $user?->isGuest ?? true;
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Html::encode(Yii::$app->language) ?>" class="h-100">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?= Html::encode($this->title ?: ($this->params['meta_title'] ?? 'Paralympic Admin')) ?></title>
    <?php $this->head() ?>
</head>
<body class="d-flex flex-column min-vh-100">
<?php $this->beginBody() ?>

<!-- Skip link helps keyboard/screen reader users jump straight to content -->
<a class="skip-link" href="#main">Skip to content</a>

<header id="header">
    <!-- App bar: custom HTML (kept) with a Bootstrap-style mobile toggler -->
    <nav class="navbar navbar-dark navbar-expand-md appbar" role="navigation" aria-label="Main navigation">
        <div class="container appbar__inner">

            <!-- Brand: symbol + small title -->
            <?= Html::a(
                Html::img(Url::to('@web/img/paralympics-mark.png'), [
                    'alt' => 'Paralympic mark',
                    'class' => 'brand__logo',
                    'loading' => 'lazy',
                    'decoding' => 'async',
                ]) . Html::tag('span', 'Paralympic Admin', ['class' => 'brand__text']),
                ['/athlete/index'],
                ['class' => 'brand', 'aria-label' => 'Go to Athletes list']
            ) ?>

            <!-- Mobile toggler (collapses/expands nav on small screens) -->
            <button class="navbar-toggler" type="button"
                    data-bs-toggle="collapse" data-bs-target="#appbarNav"
                    aria-controls="appbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Right-side nav -->
            <div class="collapse navbar-collapse" id="appbarNav">
                <ul class="navbar-nav ms-auto appbar__nav">
                    <li class="nav-item">
                        <a class="nav-link <?= $isActive('site/index') ? 'active' : '' ?>"
                           href="<?= Html::encode(Url::to(['/site/index'])) ?>"
                           <?= $isActive('site/index') ? 'aria-current="page"' : '' ?>>Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $isActive('athlete') ? 'active' : '' ?>"
                           href="<?= Html::encode(Url::to(['/athlete/index'])) ?>"
                           <?= $isActive('athlete') ? 'aria-current="page"' : '' ?>>Athletes</a>
                    </li>

                    <?php if (!$isGuest): ?>
                        <li class="nav-item">
                            <form method="post" action="<?= Html::encode(Url::to(['/site/logout'])) ?>" class="d-inline">
                                <input type="hidden" name="<?= Html::encode(Yii::$app->request->csrfParam) ?>"
                                       value="<?= Html::encode(Yii::$app->request->getCsrfToken()) ?>">
                                <button class="nav-link btn btn-link p-0 ms-3" type="submit">Logout</button>
                            </form>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <!-- <a class="nav-link" href="<?= Html::encode(Url::to(['/site/login'])) ?>">Login</a> -->
                        </li>
                    <?php endif; ?>
                </ul>
            </div>

        </div>
    </nav>

    <style>
        /* ===== App bar styling (kept your vibe, tweaked a11y/contrast) ===== */
        .appbar {
            background: linear-gradient(180deg, #1f2c3a 0%, #1b2733 100%);
            border-bottom: 1px solid #2e3f51;
            box-shadow: 0 4px 16px rgba(0, 0, 0, .12);
        }
        .appbar__inner { height: 62px; display: flex; align-items: center; }
        .brand { display: flex; align-items: center; gap: 10px; text-decoration: none; }
        .brand__logo { height: 34px; width: auto; filter: drop-shadow(0 1px 1px rgba(0,0,0,.35)); }
        .brand__text { color: #fff; font-weight: 700; font-size: 16px; letter-spacing: .2px; }
        .appbar__nav .nav-link { color: #e7eef9; font-weight: 600; }
        .appbar__nav .nav-link:hover { color: #ffffff; text-decoration: underline; }
        .appbar__nav .nav-link.active { color: #fff; text-decoration: underline; }

        /* If Bootstrap's .container isn't present, keep things centered anyway */
        .container { max-width: 1140px; margin: 0 auto; padding: 0 16px; }

        /* Skip link: visible only when tabbed to */
        .skip-link {
            position: absolute; left: -999px; top: auto; width: 1px; height: 1px; overflow: hidden;
        }
        .skip-link:focus {
            position: static; width: auto; height: auto;
            background: #fff; color: #000; padding: 6px 10px; border-radius: 6px; margin: 6px 16px; display: inline-block;
        }

        /* Content spacing: bar is NOT fixed; keep it snug */
        main#main .container { margin-top: 16px; }
        body { padding-top: 0 !important; }
        .wrap > .container { padding-top: 0 !important; }
    </style>
</header>

<main id="main" class="flex-shrink-0" role="main">
    <div class="container">
        <?php if (!empty($this->params['breadcrumbs'])): ?>
            <?= Breadcrumbs::widget(['links' => $this->params['breadcrumbs']]) ?>
        <?php endif ?>
        <?= Alert::widget() ?>
        <?= $content ?>
    </div>
</main>

<footer class="site-footer" role="contentinfo">
    <div class="container foot">
        <div class="foot__brand">
            <img class="foot__logo" src="<?= Html::encode(Url::to('@web/img/paralympics-mark.png')) ?>" alt="Paralympic mark">
            <span class="foot__title">Paralympic Admin</span>
        </div>

        <nav class="foot__links" aria-label="Footer">
            <a href="<?= Html::encode(Url::to(['/site/index'])) ?>">Home</a>
            <a href="<?= Html::encode(Url::to(['/athlete/index'])) ?>">Athletes</a>
        </nav>

        <div class="foot__copy">
            © <?= date('Y') ?> International Paralympic Committee · Demo module
        </div>
    </div>
</footer>

<style>
    /* ===== Footer styling ===== */
    .site-footer {
      background: #0f1924;
      color: #cbd5e1;
      border-top: 2px solid #01a86433;
      margin-top: auto; /* let flex push it */
    }

    .foot {
        display: grid; grid-template-columns: 1fr auto; gap: 14px; padding: 18px 16px;
    }
    .foot__brand { display: flex; align-items: center; gap: 10px; }
    .foot__logo  { height: 22px; width: auto; filter: drop-shadow(0 1px 1px rgba(0,0,0,.3)); }
    .foot__title { color: #fff; font-weight: 800; letter-spacing: .3px; }
    .foot__links { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
    .foot__links a { color: #d7e4f6; text-decoration: none; font-weight: 600; }
    .foot__links a:hover { color: #fff; text-decoration: underline; }
    .foot__copy { grid-column: 1 / -1; font-size: .95rem; color: #9fb0c6; }

    /* Stack nicely on narrow screens */
    @media (max-width: 640px) {
        .foot { grid-template-columns: 1fr; }
        .foot__links { margin-top: 4px; }
    }
</style>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
