<?php
/** @var yii\web\View $this */
use yii\helpers\Url;

$this->title = 'Paralympic Sports';

/**
 * Perf: preload the hero so it becomes the LCP image quickly.
 * If you also have a JPEG fallback next to the WebP, you can uncomment
 * the imagesrcset line.
 */
$heroWebp = Url::to('@web/img/hero-sports.webp');
$heroJpg  = Url::to('@web/img/hero-sports.jpg'); // optional fallback
$this->registerLinkTag([
    'rel'  => 'preload',
    'as'   => 'image',
    'href' => $heroWebp,
    // 'imagesrcset' => "$heroWebp type('image/webp'), $heroJpg type('image/jpeg')",
    // 'imagesizes'  => '100vw',
]);

// Short, meaningful description for screen readers about the background.
$heroAlt = 'Dynamic collage of Paralympic sports in action';
?>
<!--
  Full-bleed hero:
  - role="img" + aria-label describes the background for AT
  - Uses CSS image-set with WebP + optional JPEG fallback
  - Scrim ensures text has contrast regardless of the photo
-->
<section class="hero-full"
         role="img"
         aria-label="<?= htmlspecialchars($heroAlt, ENT_QUOTES) ?>">
    <div class="hero-full__scrim" aria-hidden="true"></div>
    <div class="hero-full__content">
        <h1 id="page-title" class="hero-title">
            PARALYMPIC<br>SPORTS
        </h1>
    </div>
</section>

<style>
    /* --- Full-bleed hero (edge-to-edge) --- */
    .hero-full {
        position: relative;
        /* Avoid scrollbar-jank on mobile: prefer svh with vh fallback */
        min-height: 100vh;
        min-height: 100svh;

        /* Full-bleed without fixed positioning; safe inside .container */
        width: 100vw;
        margin-left: calc(50% - 50vw);
        margin-right: calc(50% - 50vw);

        /* Image: first a plain fallback, then image-set for modern browsers */
        background-image: url('<?= $heroWebp ?>');
        background-image: image-set(
            url('<?= $heroWebp ?>') type('image/webp') 1x
            <?php if (is_file(Yii::getAlias('@webroot/img/hero-sports.jpg'))): ?>,
            url('<?= $heroJpg ?>') type('image/jpeg') 1x
            <?php endif; ?>
        );

        background-size: cover;
        background-position: center 40%;
        background-repeat: no-repeat;
        border-radius: 0;
    }

    .hero-full__scrim {
        position: absolute;
        inset: 0;
        /* Slightly stronger lower gradient for readability */
        background: linear-gradient(180deg, rgba(0,0,0,.38) 0%, rgba(0,0,0,.58) 100%);
        pointer-events: none;
    }

    .hero-full__content {
        position: relative;
        z-index: 1;
        height: 100%;
        display: flex;
        align-items: flex-start;
        justify-content: flex-start;
        /* Comfortable breathing room from top/left; scales with viewport */
        padding: min(14vh, 140px) 6vw;
    }

    .hero-title {
        margin: 0;
        color: #fff;
        font-weight: 900;
        line-height: .9;
        letter-spacing: .8px;
        font-size: clamp(44px, 8vw, 140px);
        text-shadow: 0 4px 18px rgba(0,0,0,.35);
    }

    /* Remove default container spacing above this page only */
    main#main .container {
        margin-top: 0 !important;
        padding: 0 15px 20px;
    }

    /* Respect users who prefer less motion (future: if you add animations) */
    @media (prefers-reduced-motion: reduce) {
        .hero-full, .hero-full__content { transition: none !important; }
    }
</style>
