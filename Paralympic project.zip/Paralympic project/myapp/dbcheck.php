<?php
try {
  $pdo = new PDO('mysql:host=127.0.0.1;dbname=athletes_db','root','');
  echo "DB OK\n";
} catch (Exception $e) {
  echo $e->getMessage(), "\n";
}
