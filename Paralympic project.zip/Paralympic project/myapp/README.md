# Athletes Module (Yii2, no scaffolding/JS, manual validators)

## Run
- XAMPP Apache + MySQL running
- Import DB schema into `athletes_db`
- Browse:
  - Pretty: `/Paralympic project/myapp/web/athlete`
  - Or: `/Paralympic project/myapp/web/index.php?r=athlete`

## Auth ($USER)
- Global `$USER` (see `web/index.php`) with methods `canView`, `canCreate`, `canUpdate`, `canDelete`.
- Action-level guard in `AthleteController::beforeAction()`.
- Record-level guard in `AthleteController::findModel()`.

## Manual Validation (no built-in validators)
- Implemented in `models/Athlete::validateCustom()`:
  - Names ≥ 3 chars
  - Age ≥ 12 on registration day
  - Sport in whitelist
  - `personalBestTime` regex `hh:mm:ss` (no DateTime parser)

## Security
- CSRF on all POST forms
- XSS-safe output via `Html::encode`
- SQLi avoided via ActiveRecord binding
- Fail-closed auth if `$USER` missing

## Files
- Model: `models/Athlete.php`
- Controller: `controllers/AthleteController.php`
- Views: `views/athlete/create.php`, `views/athlete/index.php`
- Policy: `components/UserPolicy.php`
