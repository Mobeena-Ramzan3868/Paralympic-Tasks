<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=127.0.0.1;port=3306;dbname=athletes_db',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
