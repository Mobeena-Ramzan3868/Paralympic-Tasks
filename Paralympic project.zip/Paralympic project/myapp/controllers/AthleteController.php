<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\ForbiddenHttpException;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\Athlete;

/**
 * AthleteController
 *
 * Minimal CRUD around the Athlete model with:
 * - Simple search/filter/sort/pagination for listing (no JS)
 * - Sticky forms (fields keep values on validation errors)
 * - Lightweight authorization using a global $USER (project-specific)
 */
class AthleteController extends Controller
{
    /**
     * Map controller actions to "ability" methods on our $USER object.
     * Example: visiting /athlete/create requires $USER->canCreate('athlete')
     * This is a simple, explicit gate per action.
     */
    private array $abilityMap = [
        'index' => 'canView',
        'create' => 'canCreate',
        'update' => 'canUpdate',
        'delete' => 'canDelete',
    ];

    /**
     * Limit HTTP verbs where it makes sense (extra safety on destructive actions).
     * Yii will reject DELETE attempts that are not POST here.
     */
    public function behaviors(): array
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Action-level guard.
     * Before *any* action runs, we check if the current user is allowed to do it.
     * Uses the $abilityMap above to call a corresponding method on $USER.
     */
    public function beforeAction($action)
    {
        global $USER;

        $method = $this->abilityMap[$action->id] ?? null;

        if (
            !$method // action not mapped
            || !isset($USER) // no user
            || !method_exists($USER, $method) // ability not implemented
            || !$USER->$method('athlete') // user denied for this resource type
        ) {
            throw new ForbiddenHttpException('You are not allowed to access this resource.');
        }

        // Important: if parent returns false, the action is cancelled.
        return parent::beforeAction($action);
    }

    /**
     * Helper: copy POSTed fields into the model so the form stays "sticky"
     * (values persist even when validation fails).
     */
    private function fillFromPost(Athlete $m): void
    {
        $req = Yii::$app->request;
        $m->givenName = (string) $req->post('givenName', '');
        $m->familyName = (string) $req->post('familyName', '');
        $m->dateOfBirth = (string) $req->post('dateOfBirth', '');
        $m->sport = (string) $req->post('sport', '');
        $m->personalBestTime = (string) $req->post('personalBestTime', '');
    }

    /**
     * List athletes with simple filter/sort/pagination (no JS).
     * GET params supported:
     *   q        : search in givenName/familyName
     *   sport    : filter by sport (must be valid)
     *   sort     : one of allowed fields
     *   order    : asc|desc
     *   page     : 1-based page index
     *   perPage  : items per page (5..50)
     */
    public function actionIndex()
    {
        $req = Yii::$app->request;
        $q = trim((string) $req->get('q', ''));
        $sport = (string) $req->get('sport', '');
        $sort = (string) $req->get('sort', 'created_at');
        $order = strtolower((string) $req->get('order', 'desc')) === 'asc' ? 'asc' : 'desc';

        // Only allow sorting by known columns (prevents SQL injection via orderBy).
        $allowedSorts = ['id', 'givenName', 'familyName', 'dateOfBirth', 'sport', 'personalBestTime', 'created_at'];
        if (!in_array($sort, $allowedSorts, true)) {
            $sort = 'created_at';
        }

        // Clamp pagination inputs to sensible bounds.
        $perPage = (int) $req->get('perPage', 10);
        $perPage = max(5, min($perPage, 50));
        $page = max(1, (int) $req->get('page', 1));

        // Build base query.
        $query = Athlete::find();

        if ($q !== '') {
            // Simple name search (case-insensitive LIKE on two columns).
            $query->andWhere([
                'or',
                ['like', 'givenName', $q],
                ['like', 'familyName', $q],
            ]);
        }

        if ($sport !== '' && in_array($sport, Athlete::SPORTS, true)) {
            $query->andWhere(['sport' => $sport]);
        }

        // Total before limit/offset for pagination UI.
        $total = (int) (clone $query)->count();

        // Recalculate page if it exceeds the available pages (e.g., after filters change).
        $totalPages = (int) max(1, ceil($total / $perPage));
        if ($page > $totalPages) {
            $page = $totalPages;
        }

        $offset = ($page - 1) * $perPage;
        $rowStart = $offset + 1; // for "row number" display in the view

        // Apply sort + pagination.
        $athletes = $query
            ->orderBy([$sort => ($order === 'asc' ? SORT_ASC : SORT_DESC)])
            ->limit($perPage)
            ->offset($offset)
            ->all();

        // Render list.
        return $this->render('index', compact(
            'athletes',
            'q',
            'sport',
            'sort',
            'order',
            'page',
            'perPage',
            'total',
            'totalPages',
            'rowStart'
        ));
    }

    /**
     * Create a new athlete.
     * Uses "sticky" form + custom validation defined on the model
     * (e.g. min name length, age >= 12, hh:mm:ss time format).
     */
    public function actionCreate()
    {
        $model = new Athlete();

        if (Yii::$app->request->isPost) {
            $this->fillFromPost($model);
            if ($model->validateCustom()) {
                if ($model->save(false)) {
                    Yii::$app->session->setFlash('success', 'Athlete registered successfully.');
                    return $this->redirect(['index']);
                }
                Yii::$app->session->setFlash('error', 'Failed to save athlete (database error).');
            }
        }

        return $this->render('create', ['model' => $model]);
    }

    /**
     * Update an existing athlete.
     * Reuses the same form/view as "create" (common pattern).
     */
    public function actionUpdate(int $id)
    {
        $model = $this->findModel($id, 'canUpdate');

        if (Yii::$app->request->isPost) {
            $this->fillFromPost($model);

            if ($model->validateCustom() && $model->save(false)) {
                Yii::$app->session->setFlash('success', 'Athlete updated.');
                return $this->redirect(['index']);
            }

            Yii::$app->session->setFlash('error', 'Please correct the errors below.');
        }

        // We intentionally reuse the "create" view for both create & update.
        return $this->render('create', ['model' => $model]);
    }

    /**
     * Delete an athlete.
     * Protected by CSRF (Yii forms) and HTTP verb filter (POST only).
     */
    public function actionDelete(int $id)
    {
        $model = $this->findModel($id, 'canDelete');
        $model->delete();

        Yii::$app->session->setFlash('success', 'Athlete deleted.');
        return $this->redirect(['index']);
    }

    /**
     * Fetch a specific model and do a record-level permission check.
     * Throws 404 if not found; 403 if found but access is denied.
     */
    private function findModel(int $id, string $ability = 'canView'): Athlete
    {
        global $USER;

        $m = Athlete::findOne($id);
        if (!$m) {
            throw new NotFoundHttpException('Athlete not found.');
        }

        if (!isset($USER) || !method_exists($USER, $ability) || !$USER->{$ability}('athlete', $m)) {
            throw new ForbiddenHttpException('You are not allowed to access this athlete.');
        }

        return $m;
    }
}
