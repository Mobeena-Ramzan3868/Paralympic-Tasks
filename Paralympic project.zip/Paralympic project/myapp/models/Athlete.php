<?php
namespace app\models;

use yii\db\ActiveRecord;

/**
 * Athlete model
 *
 * Notes:
 * - We use manual business-rule validation via validateCustom() as per spec.
 * - DB handles created_at (TIMESTAMP DEFAULT CURRENT_TIMESTAMP).
 * - Helpers at the bottom make it easier to render errors in views.
 */
class Athlete extends ActiveRecord
{
    /** Whitelisted sports for the dropdown/filter (UI + validation) */
    public const SPORTS = ['athletics track', 'swimming', 'cycling', 'triathlon'];

    /** Collect manual validation errors here (attribute => [messages]) */
    public array $manualErrors = [];

    /** AR table mapping */
    public static function tableName(): string
    {
        return 'athlete';
    }

    /**
     * Small helper to push a message into our manual error bag.
     * (We keep this separate from Yii's built-in addError() on purpose.)
     */
    private function addErr(string $attr, string $msg): void
    {
        $this->manualErrors[$attr][] = $msg;
    }

    /**
     * Manual validation (only) for the task’s custom rules.
     * Returns true/false and fills $manualErrors with messages.
     */
    public function validateCustom(): bool
    {
        // clear previous errors so we start fresh
        $this->manualErrors = [];

        // normalize whitespace / types
        $this->givenName = trim((string) $this->givenName);
        $this->familyName = trim((string) $this->familyName);
        $this->dateOfBirth = trim((string) $this->dateOfBirth);
        $this->sport = trim((string) $this->sport);
        $this->personalBestTime = trim((string) $this->personalBestTime);

        // a) each name part >= 3 chars (simple length check, Unicode-safe)
        if (mb_strlen($this->givenName) < 3) {
            $this->addErr('givenName', 'Given name must be at least 3 characters.');
        }
        if (mb_strlen($this->familyName) < 3) {
            $this->addErr('familyName', 'Family name must be at least 3 characters.');
        }

        // b) DOB valid (Y-m-d) + age >= 12 "today"
        $dob = \DateTime::createFromFormat('Y-m-d', $this->dateOfBirth);
        $errs = \DateTime::getLastErrors(); // catches invalid 2024-02-30 etc.
        if (!$dob || !empty($errs['warning_count']) || !empty($errs['error_count'])) {
            $this->addErr('dateOfBirth', 'Date of birth must be a valid date (Y-m-d).');
        } else {
            $age = $dob->diff(new \DateTime('today'))->y;
            if ($age < 12) {
                $this->addErr('dateOfBirth', 'Athlete must be at least 12 years old on the day of registration.');
            }
        }

        // c) sport must be one of the allowed options
        if (!in_array($this->sport, self::SPORTS, true)) {
            $this->addErr('sport', 'Sport must be one of: ' . implode(', ', self::SPORTS));
        }

        // d) time format exactly hh:mm:ss (no DateTime parser by requirement).
        // We intentionally allow hours 00–99 (ultra-long events still allowed).
        if (!preg_match('/^\d{2}:[0-5]\d:[0-5]\d$/', $this->personalBestTime)) {
            $this->addErr('personalBestTime', 'Time must be in format hh:mm:ss (e.g. 02:45:09).');
        }

        return empty($this->manualErrors);
    }

    /** Read-only accessor for templates/components that want the bag as-is. */
    public function getManualErrors(): array
    {
        return $this->manualErrors;
    }

    /**
     * Optional bridge: copy manual errors into Yii’s internal error store.
     * Call this from the controller *after* validateCustom() if you want
     * ActiveForm’s standard error rendering without custom view code.
     *
     * Example:
     *   if (!$model->validateCustom()) {
     *       $model->pushManualErrorsToYii();
     *   }
     */
    public function pushManualErrorsToYii(): void
    {
        foreach ($this->manualErrors as $attr => $messages) {
            foreach ($messages as $msg) {
                $this->addError($attr, $msg);
            }
        }
    }

    /**
     * Convenience for views: return errors for a single attribute,
     * merging manual bag + Yii errors (future-proof if rules() are added).
     */
    public function errorsFor(string $attr): array
    {
        $manual = $this->manualErrors[$attr] ?? [];
        $yii = $this->getErrors($attr);
        return array_values(array_unique(array_merge($manual, $yii)));
    }

    /** Handy for dropdowns: ['swimming' => 'swimming', ...] */
    public static function sportsOptions(): array
    {
        return array_combine(self::SPORTS, self::SPORTS);
    }

    /** Pretty labels for forms/tables */
    public function attributeLabels(): array
    {
        return [
            'givenName' => 'Given Name',
            'familyName' => 'Family Name',
            'dateOfBirth' => 'Date of Birth',
            'sport' => 'Sport',
            'personalBestTime' => 'Personal Best Time (hh:mm:ss)',
            'created_at' => 'Created',
        ];
    }
}
